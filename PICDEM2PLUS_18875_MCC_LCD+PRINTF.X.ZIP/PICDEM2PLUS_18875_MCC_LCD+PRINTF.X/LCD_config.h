//##############################################################################
//    filename:        lcd_config.h
//##############################################################################
//    configuration file for LCD library (pins, voltage, delays ...)
//##############################################################################
//      Author:            	V.SchK
//      Company:        	HS-Ulm
//      Adapted:            AS
//      Revision:        	2.0 (for XC8)
//      Date:         		April 2020
//     	Compiler            XC8 v2.10
//      MPLAB X             v5.35
//      MCC                 v3.95
//##############################################################################

#ifndef _LCD_CONFIG_H
#define _LCD_CONFIG_H

#define LCD_TIMEOUT 100

#define SPLC782A        // Select SPLC782A LCD CTRL delay template

// Check the LCD controller IC and adapt below delays
// Relies on delays provided by XC8 compiler library computed by MCC
#warning "!!! LCD Delays depend upon your LCD module/controller !!!"
#if defined SPLC782A
    #define LongCommand2ms()    __delay_ms (2);     // depend upon LCD controller
    #define MiddleCommand40us() __delay_us (40);    // depend upon LCD controller
    #define ShortDelay1us()     __delay_us (1);     // depend upon LCD controller
    #define PowerupDelay()      __delay_ms (200);   // depend upon power supply
    #define DelayAfterPowerOn() __delay_ms (40);    // depend upon power supply    
#endif

#define LCD_DELAY_1US()     __delay_us (1); //ASO
#define LCD_DELAY_100US()   __delay_us (100); //ASO
#define LCD_DELAY_5MS()     __delay_ms (5); //ASO
#define LCD_DELAY_15MS()    __delay_ms (15); //ASO


// uncomment the board in use or define a custom pinning ;-) --------------------

//    #define PICDEM2p_2002
//    #define PICDEM2p_2006
      #define PICDEM2p_2010     //ASO
//    #define PIC_ADAPTER
//    #define EXT_LCD_3_3_V   //DOG... displays
//    #define EXT_LCD_5_V

//      custom boards at the end

    #if defined PICDEM2p_2002
        #warning "LCD-pinning for PICDEM2+ 2002 !!!"
        #define	LCD_E		LATAbits.LATA1
        #define	LCD_E_DIR	TRISAbits.TRISA1
        #define	LCD_RW		LATAbits.LATA2
        #define	LCD_RW_DIR	TRISAbits.TRISA2
        #define	LCD_RS		LATAbits.LATA3
        #define	LCD_RS_DIR	TRISAbits.TRISA3

        #define	LCD_D4_IN	PORTDbits.RD0
        #define	LCD_D5_IN	PORTDbits.RD1
        #define	LCD_D6_IN	PORTDbits.RD2
        #define	LCD_D7_IN	PORTDbits.RD3
        #define	LCD_D4_OUT	LATDbits.LATD0
        #define	LCD_D5_OUT	LATDbits.LATD1
        #define	LCD_D6_OUT	LATDbits.LATD2
        #define	LCD_D7_OUT	LATDbits.LATD3
        #define	LCD_D4_DIR	TRISDbits.TRISD0
        #define	LCD_D5_DIR	TRISDbits.TRISD1
        #define	LCD_D6_DIR	TRISDbits.TRISD2
        #define	LCD_D7_DIR	TRISDbits.TRISD3

    #elif defined(PICDEM2p_2006) || defined(PIC_ADAPTER)
        #warning "LCD-pinning for PICDEM2+ 2006 !!!"
        #define	LCD_E		LATDbits.LATD6
        #define	LCD_E_DIR	TRISDbits.TRISD6
        #define	LCD_RW		LATDbits.LATD5
        #define	LCD_RW_DIR	TRISDbits.TRISD5
        #define	LCD_RS		LATDbits.LATD4
        #define	LCD_RS_DIR	TRISDbits.TRISD4

        #define	LCD_D4_IN	PORTDbits.RD0
        #define	LCD_D5_IN	PORTDbits.RD1
        #define	LCD_D6_IN	PORTDbits.RD2
        #define	LCD_D7_IN	PORTDbits.RD3
        #define	LCD_D4_OUT	LATDbits.LATD0
        #define	LCD_D5_OUT	LATDbits.LATD1
        #define	LCD_D6_OUT	LATDbits.LATD2
        #define	LCD_D7_OUT	LATDbits.LATD3
        #define	LCD_D4_DIR	TRISDbits.TRISD0
        #define	LCD_D5_DIR	TRISDbits.TRISD1
        #define	LCD_D6_DIR	TRISDbits.TRISD2
        #define	LCD_D7_DIR	TRISDbits.TRISD3

    #elif defined(PICDEM2p_2010)
        #warning "LCD-pinning for PICDEM2+ 2010 !!!"
        #define	LCD_E		LATDbits.LATD6
        #define	LCD_E_DIR	TRISDbits.TRISD6
        #define	LCD_RW		LATDbits.LATD5
        #define	LCD_RW_DIR	TRISDbits.TRISD5
        #define	LCD_RS		LATDbits.LATD4
        #define	LCD_RS_DIR	TRISDbits.TRISD4

        #define	LCD_D4_IN	PORTDbits.RD0
        #define	LCD_D5_IN	PORTDbits.RD1
        #define	LCD_D6_IN	PORTDbits.RD2
        #define	LCD_D7_IN	PORTDbits.RD3
        #define	LCD_D4_OUT	LATDbits.LATD0
        #define	LCD_D5_OUT	LATDbits.LATD1
        #define	LCD_D6_OUT	LATDbits.LATD2
        #define	LCD_D7_OUT	LATDbits.LATD3
        #define	LCD_D4_DIR	TRISDbits.TRISD0
        #define	LCD_D5_DIR	TRISDbits.TRISD1
        #define	LCD_D6_DIR	TRISDbits.TRISD2
        #define	LCD_D7_DIR	TRISDbits.TRISD3
    #else
        #error PLEASE SPECIFY LCD CONNECTIONS !
    #endif

  #ifdef PICDEM2p_2006
    #define LCD_ON      LATDbits.LATD7
    #define LCD_ON_DIR  TRISDbits.TRISD7
  #endif

  #ifdef PICDEM2p_2010
    #define LCD_ON      LATDbits.LATD7
    #define LCD_ON_DIR  TRISDbits.TRISD7
  #endif
#endif //_LCD_CONFIG_H
